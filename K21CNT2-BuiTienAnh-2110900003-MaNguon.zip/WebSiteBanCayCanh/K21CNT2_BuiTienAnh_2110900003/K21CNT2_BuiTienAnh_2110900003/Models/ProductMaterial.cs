﻿using System;
using System.Collections.Generic;

namespace K21CNT2_BuiTienAnh_2110900003.Models​;

public partial class ProductMaterial
{
    public int Id { get; set; }

    public int? Pid { get; set; }

    public int? Mid { get; set; }
}
